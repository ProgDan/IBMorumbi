// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.view.View;

// Referenced classes of package android.support.v7.widget:
//            i

final class a extends i
{

    a()
    {
    }

    int a(View view, int j)
    {
        return 0x80000000;
    }

    public int b(View view, int j)
    {
        return 0x80000000;
    }
}
