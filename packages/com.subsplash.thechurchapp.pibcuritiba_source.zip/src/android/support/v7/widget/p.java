// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.a.c;
import android.util.AttributeSet;

// Referenced classes of package android.support.v7.widget:
//            o, s, GridLayout

public class p extends android.view.ViewGroup.MarginLayoutParams
{

    private static final o c;
    private static final int d;
    public s a;
    public s b;

    public p()
    {
        this(s.a, s.a);
    }

    private p(int i, int j, int k, int l, int i1, int j1, s s1, 
            s s2)
    {
        super(i, j);
        a = s.a;
        b = s.a;
        setMargins(k, l, i1, j1);
        a = s1;
        b = s2;
    }

    public p(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        a = s.a;
        b = s.a;
        a(context, attributeset);
        b(context, attributeset);
    }

    public p(s s1, s s2)
    {
        this(-2, -2, 0x80000000, 0x80000000, 0x80000000, 0x80000000, s1, s2);
    }

    public p(android.view.ViewGroup.LayoutParams layoutparams)
    {
        super(layoutparams);
        a = s.a;
        b = s.a;
    }

    private void a(Context context, AttributeSet attributeset)
    {
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, c.GridLayout_Layout);
        int i = typedarray.getDimensionPixelSize(2, 0x80000000);
        leftMargin = typedarray.getDimensionPixelSize(3, i);
        topMargin = typedarray.getDimensionPixelSize(4, i);
        rightMargin = typedarray.getDimensionPixelSize(5, i);
        bottomMargin = typedarray.getDimensionPixelSize(6, i);
        typedarray.recycle();
        return;
        Exception exception;
        exception;
        typedarray.recycle();
        throw exception;
    }

    private void b(Context context, AttributeSet attributeset)
    {
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, c.GridLayout_Layout);
        int i = typedarray.getInt(11, 0);
        b = GridLayout.a(typedarray.getInt(9, 0x80000000), typedarray.getInt(10, d), GridLayout.a(i, true));
        a = GridLayout.a(typedarray.getInt(7, 0x80000000), typedarray.getInt(8, d), GridLayout.a(i, false));
        typedarray.recycle();
        return;
        Exception exception;
        exception;
        typedarray.recycle();
        throw exception;
    }

    public void a(int i)
    {
        a = a.a(GridLayout.a(i, false));
        b = b.a(GridLayout.a(i, true));
    }

    final void a(o o1)
    {
        a = a.a(o1);
    }

    final void b(o o1)
    {
        b = b.a(o1);
    }

    public boolean equals(Object obj)
    {
        if (this != obj)
        {
            if (obj == null || getClass() != obj.getClass())
            {
                return false;
            }
            p p1 = (p)obj;
            if (!b.equals(p1.b))
            {
                return false;
            }
            if (!a.equals(p1.a))
            {
                return false;
            }
        }
        return true;
    }

    public int hashCode()
    {
        return 31 * a.hashCode() + b.hashCode();
    }

    protected void setBaseAttributes(TypedArray typedarray, int i, int j)
    {
        width = typedarray.getLayoutDimension(i, -2);
        height = typedarray.getLayoutDimension(j, -2);
    }

    static 
    {
        c = new o(0x80000000, 0x80000001);
        d = c.a();
    }
}
