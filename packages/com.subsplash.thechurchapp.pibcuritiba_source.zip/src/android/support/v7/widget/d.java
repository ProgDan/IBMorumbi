// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.view.View;

// Referenced classes of package android.support.v7.widget:
//            i, u

final class d extends i
{

    final i a;
    final i b;

    d(i j, i k)
    {
        a = j;
        b = k;
        super();
    }

    int a(View view, int j)
    {
        i k;
        if (!u.b(view))
        {
            k = a;
        } else
        {
            k = b;
        }
        return k.a(view, j);
    }

    public int b(View view, int j)
    {
        i k;
        if (!u.b(view))
        {
            k = a;
        } else
        {
            k = b;
        }
        return k.b(view, j);
    }
}
