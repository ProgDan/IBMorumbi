// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package android.support.v7.widget:
//            GridLayout, a

final class r
{

    public final int a[];
    public final Object b[];
    public final Object c[];

    private r(Object aobj[], Object aobj1[])
    {
        a = a(aobj);
        b = a(aobj, a);
        c = a(aobj1, a);
    }

    r(Object aobj[], Object aobj1[], a a1)
    {
        this(aobj, aobj1);
    }

    private static int[] a(Object aobj[])
    {
        int i = aobj.length;
        int ai[] = new int[i];
        HashMap hashmap = new HashMap();
        for (int j = 0; j < i; j++)
        {
            Object obj = aobj[j];
            Integer integer = (Integer)hashmap.get(obj);
            if (integer == null)
            {
                integer = Integer.valueOf(hashmap.size());
                hashmap.put(obj, integer);
            }
            ai[j] = integer.intValue();
        }

        return ai;
    }

    private static Object[] a(Object aobj[], int ai[])
    {
        int i = aobj.length;
        Object aobj1[] = (Object[])(Object[])Array.newInstance(((Object) (aobj)).getClass().getComponentType(), 1 + GridLayout.a(ai, -1));
        for (int j = 0; j < i; j++)
        {
            aobj1[ai[j]] = aobj[j];
        }

        return aobj1;
    }

    public Object a(int i)
    {
        return c[a[i]];
    }
}
