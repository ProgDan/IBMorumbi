// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;


// Referenced classes of package android.support.v7.widget:
//            GridLayout, o, i, a

public class s
{

    static final s a = GridLayout.a(0x80000000);
    final boolean b;
    final o c;
    final i d;

    private s(boolean flag, int i, int j, i k)
    {
        this(flag, new o(i, i + j), k);
    }

    s(boolean flag, int i, int j, i k, a a1)
    {
        this(flag, i, j, k);
    }

    private s(boolean flag, o o1, i i)
    {
        b = flag;
        c = o1;
        d = i;
    }

    final int a()
    {
        return d != GridLayout.j ? 2 : 0;
    }

    final s a(i i)
    {
        return new s(b, c, i);
    }

    final s a(o o1)
    {
        return new s(b, o1, d);
    }

    public boolean equals(Object obj)
    {
        if (this != obj)
        {
            if (obj == null || getClass() != obj.getClass())
            {
                return false;
            }
            s s1 = (s)obj;
            if (!d.equals(s1.d))
            {
                return false;
            }
            if (!c.equals(s1.c))
            {
                return false;
            }
        }
        return true;
    }

    public int hashCode()
    {
        return 31 * c.hashCode() + d.hashCode();
    }

}
