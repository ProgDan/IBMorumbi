// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.view.View;

// Referenced classes of package android.support.v7.widget:
//            i, GridLayout, s, l, 
//            a

class n
{

    public int b;
    public int c;
    public int d;

    private n()
    {
        a();
    }

    n(a a1)
    {
        this();
    }

    protected int a(View view, i j, int k)
    {
        return b - j.b(view, k);
    }

    protected int a(boolean flag)
    {
        if (!flag && GridLayout.b(d))
        {
            return 0x186a0;
        } else
        {
            return b + c;
        }
    }

    protected void a()
    {
        b = 0x80000000;
        c = 0x80000000;
        d = 2;
    }

    protected void a(int j, int k)
    {
        b = Math.max(b, j);
        c = Math.max(c, k);
    }

    protected final void a(View view, s s1, GridLayout gridlayout, l l1)
    {
        d = d & s1.a();
        int j = gridlayout.a(view, l1.a);
        int k = gridlayout.a(s1.d, l1.a).b(view, j);
        a(k, j - k);
    }

    public String toString()
    {
        return (new StringBuilder()).append("Bounds{before=").append(b).append(", after=").append(c).append('}').toString();
    }
}
