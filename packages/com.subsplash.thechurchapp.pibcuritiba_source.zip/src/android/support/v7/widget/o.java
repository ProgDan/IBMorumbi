// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;


final class o
{

    public final int a;
    public final int b;

    public o(int i, int j)
    {
        a = i;
        b = j;
    }

    int a()
    {
        return b - a;
    }

    o b()
    {
        return new o(b, a);
    }

    public boolean equals(Object obj)
    {
        if (this != obj)
        {
            if (obj == null || getClass() != obj.getClass())
            {
                return false;
            }
            o o1 = (o)obj;
            if (b != o1.b)
            {
                return false;
            }
            if (a != o1.a)
            {
                return false;
            }
        }
        return true;
    }

    public int hashCode()
    {
        return 31 * a + b;
    }

    public String toString()
    {
        return (new StringBuilder()).append("[").append(a).append(", ").append(b).append("]").toString();
    }
}
