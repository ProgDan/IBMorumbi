// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.util.Log;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package android.support.v7.widget:
//            GridLayout, q, r, n, 
//            j, o, k, s, 
//            m, p, i, a

final class l
{

    static final boolean r;
    public final boolean a;
    public int b;
    r c;
    public boolean d;
    r e;
    public boolean f;
    r g;
    public boolean h;
    public int i[];
    public boolean j;
    public int k[];
    public boolean l;
    public j m[];
    public boolean n;
    public int o[];
    public boolean p;
    boolean q;
    final GridLayout s;
    private int t;
    private q u;
    private q v;

    private l(GridLayout gridlayout, boolean flag)
    {
        s = gridlayout;
        super();
        b = 0x80000000;
        t = 0x80000000;
        d = false;
        f = false;
        h = false;
        j = false;
        l = false;
        n = false;
        p = false;
        q = true;
        u = new q(0);
        v = new q(0xfffe7960);
        a = flag;
    }

    l(GridLayout gridlayout, boolean flag, a a1)
    {
        this(gridlayout, flag);
    }

    private void a(int i1, int j1)
    {
        u.a = i1;
        v.a = -j1;
        p = false;
    }

    private void a(r r1, boolean flag)
    {
        int i1 = 0;
        q aq[] = (q[])r1.c;
        for (int j1 = 0; j1 < aq.length; j1++)
        {
            aq[j1].a();
        }

        n an[] = (n[])b().c;
        while (i1 < an.length) 
        {
            int k1 = an[i1].a(flag);
            q q1 = (q)r1.a(i1);
            int l1 = q1.a;
            if (!flag)
            {
                k1 = -k1;
            }
            q1.a = Math.max(l1, k1);
            i1++;
        }
    }

    private void a(String s1, j aj[], boolean aflag[])
    {
        ArrayList arraylist = new ArrayList();
        ArrayList arraylist1 = new ArrayList();
        for (int i1 = 0; i1 < aj.length; i1++)
        {
            j j1 = aj[i1];
            if (aflag[i1])
            {
                arraylist.add(j1);
            }
            if (!j1.c)
            {
                arraylist1.add(j1);
            }
        }

        Log.d(GridLayout.a, (new StringBuilder()).append(s1).append(" constraints: ").append(b(arraylist)).append(" are inconsistent; ").append("permanently removing: ").append(b(arraylist1)).append(". ").toString());
    }

    private void a(List list, o o1, q q1)
    {
        a(list, o1, q1, true);
    }

    private void a(List list, o o1, q q1, boolean flag)
    {
label0:
        {
            if (o1.a() == 0)
            {
                return;
            }
            if (!flag)
            {
                break label0;
            }
            Iterator iterator = list.iterator();
            do
            {
                if (!iterator.hasNext())
                {
                    break label0;
                }
            } while (!((j)iterator.next()).a.equals(o1));
            return;
        }
        list.add(new j(o1, q1));
    }

    private void a(List list, r r1)
    {
        for (int i1 = 0; i1 < ((o[])r1.b).length; i1++)
        {
            a(list, ((o[])r1.b)[i1], ((q[])r1.c)[i1], false);
        }

    }

    private void a(int ai[])
    {
        Arrays.fill(ai, 0);
    }

    private void a(j aj[], int ai[])
    {
        String s1;
        int i1;
        boolean aflag[];
        int j1;
        int k1;
        boolean flag;
        int i3;
        int j3;
        if (a)
        {
            s1 = "horizontal";
        } else
        {
            s1 = "vertical";
        }
        i1 = 1 + a();
        aflag = null;
        j1 = 0;
_L8:
        if (j1 >= aj.length) goto _L2; else goto _L1
_L1:
        a(ai);
        k1 = 0;
_L6:
        if (k1 >= i1)
        {
            break; /* Loop/switch isn't completed */
        }
        i3 = aj.length;
        j3 = 0;
        flag = false;
        for (; j3 < i3; j3++)
        {
            flag |= a(ai, aj[j3]);
        }

        if (flag) goto _L4; else goto _L3
_L3:
        if (aflag != null)
        {
            a(s1, aj, aflag);
        }
_L2:
        return;
_L4:
        k1++;
        if (true) goto _L6; else goto _L5
_L5:
label0:
        {
            boolean aflag1[] = new boolean[aj.length];
            for (int l1 = 0; l1 < i1; l1++)
            {
                int k2 = aj.length;
                for (int l2 = 0; l2 < k2; l2++)
                {
                    aflag1[l2] = aflag1[l2] | a(ai, aj[l2]);
                }

            }

            if (j1 == 0)
            {
                aflag = aflag1;
            }
            int i2 = 0;
            j j2;
            do
            {
                if (i2 >= aj.length)
                {
                    break label0;
                }
                if (aflag1[i2])
                {
                    j2 = aj[i2];
                    if (j2.a.a >= j2.a.b)
                    {
                        break;
                    }
                }
                i2++;
            } while (true);
            j2.c = false;
        }
        j1++;
        if (true) goto _L8; else goto _L7
_L7:
    }

    private boolean a(int ai[], j j1)
    {
        if (j1.c)
        {
            o o1 = j1.a;
            int i1 = o1.a;
            int k1 = o1.b;
            int l1 = j1.b.a + ai[i1];
            if (l1 > ai[k1])
            {
                ai[k1] = l1;
                return true;
            }
        }
        return false;
    }

    private j[] a(List list)
    {
        return b((j[])list.toArray(new j[list.size()]));
    }

    private int b(int i1, int j1)
    {
        a(i1, j1);
        return c(f());
    }

    private r b(boolean flag)
    {
        k k1 = android.support.v7.widget.k.a(android/support/v7/widget/o, android/support/v7/widget/q);
        s as[] = (s[])b().b;
        int i1 = as.length;
        int j1 = 0;
        while (j1 < i1) 
        {
            o o1;
            if (flag)
            {
                o1 = as[j1].c;
            } else
            {
                o1 = as[j1].c.b();
            }
            k1.a(o1, new q());
            j1++;
        }
        return k1.a();
    }

    private String b(List list)
    {
        String s1;
        StringBuilder stringbuilder;
        Iterator iterator;
        StringBuilder stringbuilder1;
        boolean flag;
        if (a)
        {
            s1 = "x";
        } else
        {
            s1 = "y";
        }
        stringbuilder = new StringBuilder();
        iterator = list.iterator();
        stringbuilder1 = stringbuilder;
        flag = true;
        while (iterator.hasNext()) 
        {
            j j1 = (j)iterator.next();
            int i1;
            int k1;
            int l1;
            String s2;
            if (flag)
            {
                flag = false;
            } else
            {
                stringbuilder1 = stringbuilder1.append(", ");
            }
            i1 = j1.a.a;
            k1 = j1.a.b;
            l1 = j1.b.a;
            if (i1 < k1)
            {
                s2 = (new StringBuilder()).append(s1).append(k1).append(" - ").append(s1).append(i1).append(" > ").append(l1).toString();
            } else
            {
                s2 = (new StringBuilder()).append(s1).append(i1).append(" - ").append(s1).append(k1).append(" < ").append(-l1).toString();
            }
            stringbuilder1.append(s2);
        }
        return stringbuilder1.toString();
    }

    private void b(int ai[])
    {
        int i1 = 0;
        a(c(), ai);
        if (!q)
        {
            int j1 = ai[0];
            for (int k1 = ai.length; i1 < k1; i1++)
            {
                ai[i1] = ai[i1] - j1;
            }

        }
    }

    private j[] b(j aj[])
    {
        return (new m(this, aj)).a();
    }

    private int c(int ai[])
    {
        return ai[a()];
    }

    private void c(boolean flag)
    {
        int ai[];
        int i1;
        int j1;
        if (flag)
        {
            ai = i;
        } else
        {
            ai = k;
        }
        i1 = s.getChildCount();
        j1 = 0;
        while (j1 < i1) 
        {
            View view = s.getChildAt(j1);
            if (view.getVisibility() != 8)
            {
                p p1 = s.a(view);
                s s1;
                o o1;
                int k1;
                if (a)
                {
                    s1 = p1.b;
                } else
                {
                    s1 = p1.a;
                }
                o1 = s1.c;
                if (flag)
                {
                    k1 = o1.a;
                } else
                {
                    k1 = o1.b;
                }
                ai[k1] = Math.max(ai[k1], s.a(view, a, flag));
            }
            j1++;
        }
    }

    private int i()
    {
        int i1 = s.getChildCount();
        int j1 = 0;
        int k1 = -1;
        while (j1 < i1) 
        {
            View view = s.getChildAt(j1);
            p p1 = s.a(view);
            s s1;
            o o1;
            if (a)
            {
                s1 = p1.b;
            } else
            {
                s1 = p1.a;
            }
            o1 = s1.c;
            k1 = Math.max(Math.max(k1, o1.a), o1.b);
            j1++;
        }
        if (k1 == -1)
        {
            return 0x80000000;
        } else
        {
            return k1;
        }
    }

    private int j()
    {
        if (t == 0x80000000)
        {
            t = Math.max(0, i());
        }
        return t;
    }

    private r k()
    {
        k k1 = android.support.v7.widget.k.a(android/support/v7/widget/s, android/support/v7/widget/n);
        int i1 = s.getChildCount();
        int j1 = 0;
        while (j1 < i1) 
        {
            View view = s.getChildAt(j1);
            p p1 = s.a(view);
            s s1;
            if (a)
            {
                s1 = p1.b;
            } else
            {
                s1 = p1.a;
            }
            k1.a(s1, s.a(s1.d, a).a());
            j1++;
        }
        return k1.a();
    }

    private void l()
    {
        int i1 = 0;
        n an[] = (n[])c.c;
        for (int j1 = 0; j1 < an.length; j1++)
        {
            an[j1].a();
        }

        int k1 = s.getChildCount();
        while (i1 < k1) 
        {
            View view = s.getChildAt(i1);
            p p1 = s.a(view);
            s s1;
            if (a)
            {
                s1 = p1.b;
            } else
            {
                s1 = p1.a;
            }
            ((n)c.a(i1)).a(view, s1, s, this);
            i1++;
        }
    }

    private r m()
    {
        if (e == null)
        {
            e = b(true);
        }
        if (!f)
        {
            a(e, true);
            f = true;
        }
        return e;
    }

    private r n()
    {
        if (g == null)
        {
            g = b(false);
        }
        if (!h)
        {
            a(g, false);
            h = true;
        }
        return g;
    }

    private j[] o()
    {
        ArrayList arraylist = new ArrayList();
        ArrayList arraylist1 = new ArrayList();
        a(arraylist, m());
        a(arraylist1, n());
        if (q)
        {
            for (int j1 = 0; j1 < a(); j1++)
            {
                a(arraylist, new o(j1, j1 + 1), new q(0));
            }

        }
        int i1 = a();
        a(arraylist, new o(0, i1), u, false);
        a(arraylist1, new o(i1, 0), v, false);
        return (j[])GridLayout.a(a(arraylist), a(arraylist1));
    }

    private void p()
    {
        m();
        n();
    }

    public int a()
    {
        return Math.max(b, j());
    }

    public void a(int i1)
    {
        b = i1;
    }

    public void a(boolean flag)
    {
        q = flag;
        g();
    }

    j[][] a(j aj[])
    {
        int i1 = 0;
        int j1 = 1 + a();
        j aj1[][] = new j[j1][];
        int ai[] = new int[j1];
        int k1 = aj.length;
        for (int l1 = 0; l1 < k1; l1++)
        {
            int i3 = aj[l1].a.a;
            ai[i3] = 1 + ai[i3];
        }

        for (int i2 = 0; i2 < ai.length; i2++)
        {
            aj1[i2] = new j[ai[i2]];
        }

        Arrays.fill(ai, 0);
        for (int j2 = aj.length; i1 < j2; i1++)
        {
            j j3 = aj[i1];
            int k2 = j3.a.a;
            j aj2[] = aj1[k2];
            int l2 = ai[k2];
            ai[k2] = l2 + 1;
            aj2[l2] = j3;
        }

        return aj1;
    }

    public int b(int i1)
    {
        int k1;
label0:
        {
label1:
            {
                int j1 = android.view.View.MeasureSpec.getMode(i1);
                k1 = android.view.View.MeasureSpec.getSize(i1);
                int l1;
                switch (j1)
                {
                default:
                    boolean flag = r;
                    l1 = 0;
                    if (!flag)
                    {
                        throw new AssertionError();
                    }
                    break;

                case -2147483648: 
                    break label0;

                case 1073741824: 
                    break label1;

                case 0: // '\0'
                    l1 = b(0, 0x186a0);
                    break;
                }
                return l1;
            }
            return b(k1, k1);
        }
        return b(0, k1);
    }

    public r b()
    {
        if (c == null)
        {
            c = k();
        }
        if (!d)
        {
            l();
            d = true;
        }
        return c;
    }

    public void c(int i1)
    {
        a(i1, i1);
        f();
    }

    public j[] c()
    {
        if (m == null)
        {
            m = o();
        }
        if (!n)
        {
            p();
            n = true;
        }
        return m;
    }

    public int[] d()
    {
        if (i == null)
        {
            i = new int[1 + a()];
        }
        if (!j)
        {
            c(true);
            j = true;
        }
        return i;
    }

    public int[] e()
    {
        if (k == null)
        {
            k = new int[1 + a()];
        }
        if (!l)
        {
            c(false);
            l = true;
        }
        return k;
    }

    public int[] f()
    {
        if (o == null)
        {
            o = new int[1 + a()];
        }
        if (!p)
        {
            b(o);
            p = true;
        }
        return o;
    }

    public void g()
    {
        t = 0x80000000;
        c = null;
        e = null;
        g = null;
        i = null;
        k = null;
        m = null;
        o = null;
        h();
    }

    public void h()
    {
        d = false;
        f = false;
        h = false;
        j = false;
        l = false;
        n = false;
        p = false;
    }

    static 
    {
        boolean flag;
        if (!android/support/v7/widget/GridLayout.desiredAssertionStatus())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        r = flag;
    }
}
