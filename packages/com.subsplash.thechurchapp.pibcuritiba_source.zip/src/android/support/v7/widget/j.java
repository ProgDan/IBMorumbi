// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;


// Referenced classes of package android.support.v7.widget:
//            o, q

final class j
{

    public final o a;
    public final q b;
    public boolean c;

    public j(o o, q q)
    {
        c = true;
        a = o;
        b = q;
    }

    public String toString()
    {
        StringBuilder stringbuilder = (new StringBuilder()).append(a).append(" ");
        String s;
        if (!c)
        {
            s = "+>";
        } else
        {
            s = "->";
        }
        return stringbuilder.append(s).append(" ").append(b).toString();
    }
}
