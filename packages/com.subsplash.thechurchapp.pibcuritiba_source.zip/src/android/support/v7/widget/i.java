// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.view.View;

// Referenced classes of package android.support.v7.widget:
//            n

public abstract class i
{

    i()
    {
    }

    abstract int a(View view, int j);

    int a(View view, int j, int k)
    {
        return j;
    }

    n a()
    {
        return new n(null);
    }

    abstract int b(View view, int j);
}
