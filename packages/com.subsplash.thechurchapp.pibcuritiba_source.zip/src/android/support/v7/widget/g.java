// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.view.View;

// Referenced classes of package android.support.v7.widget:
//            n, f, i

class g extends n
{

    final f a;
    private int e;

    g(f f)
    {
        a = f;
        super(null);
    }

    protected int a(View view, i i, int j)
    {
        return Math.max(0, super.a(view, i, j));
    }

    protected int a(boolean flag)
    {
        return Math.max(super.a(flag), e);
    }

    protected void a()
    {
        super.a();
        e = 0x80000000;
    }

    protected void a(int i, int j)
    {
        super.a(i, j);
        e = Math.max(e, i + j);
    }
}
