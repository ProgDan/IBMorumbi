// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

abstract class u extends ViewGroup
{

    public u(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
    }

    public static int a(int i, int j, int k)
    {
        int l;
        int i1;
        if (android.os.Build.VERSION.SDK_INT >= 11)
        {
            return View.resolveSizeAndState(i, j, k);
        }
        l = android.view.View.MeasureSpec.getMode(j);
        i1 = android.view.View.MeasureSpec.getSize(j);
        l;
        JVM INSTR lookupswitch 3: default 60
    //                   -2147483648: 67
    //                   0: 60
    //                   1073741824: 82;
           goto _L1 _L2 _L1 _L3
_L1:
        return i | 0xff000000 & k;
_L2:
        if (i1 < i)
        {
            i = i1 | 0x1000000;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        i = i1;
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected static boolean b(View view)
    {
        return false;
    }
}
