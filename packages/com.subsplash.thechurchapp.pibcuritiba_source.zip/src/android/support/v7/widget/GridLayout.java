// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.support.v7.a.b;
import android.support.v7.a.c;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.reflect.Array;
import java.util.Arrays;

// Referenced classes of package android.support.v7.widget:
//            u, a, b, c, 
//            e, f, h, l, 
//            o, p, s, d, 
//            t, r, n, i

public class GridLayout extends u
{

    static final String a = android/support/v7/widget/GridLayout.getName();
    static final i j = new a();
    public static final i k;
    public static final i l;
    public static final i m;
    public static final i n;
    public static final i o;
    public static final i p;
    public static final i q = new e();
    public static final i r = new f();
    public static final i s = new h();
    private static final i t;
    private static final i u;
    final l b;
    final l c;
    boolean d;
    int e;
    boolean f;
    int g;
    int h;
    int i;

    public GridLayout(Context context)
    {
        this(context, null);
    }

    public GridLayout(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public GridLayout(Context context, AttributeSet attributeset, int i1)
    {
        TypedArray typedarray;
        super(context, attributeset, i1);
        b = new l(this, true, null);
        c = new l(this, false, null);
        d = false;
        e = 0;
        f = false;
        g = 1;
        i = 0;
        h = context.getResources().getDimensionPixelOffset(b.default_gap);
        typedarray = context.obtainStyledAttributes(attributeset, c.GridLayout);
        setRowCount(typedarray.getInt(1, 0x80000000));
        setColumnCount(typedarray.getInt(2, 0x80000000));
        setOrientation(typedarray.getInt(0, 0));
        setUseDefaultMargins(typedarray.getBoolean(3, false));
        setAlignmentMode(typedarray.getInt(4, 1));
        setRowOrderPreserved(typedarray.getBoolean(5, true));
        setColumnOrderPreserved(typedarray.getBoolean(6, true));
        typedarray.recycle();
        return;
        Exception exception;
        exception;
        typedarray.recycle();
        throw exception;
    }

    private static int a(o o1, boolean flag, int i1)
    {
        int j1 = o1.a();
        if (i1 == 0)
        {
            return j1;
        }
        int k1;
        if (flag)
        {
            k1 = Math.min(o1.a, i1);
        } else
        {
            k1 = 0;
        }
        return Math.min(j1, i1 - k1);
    }

    private int a(View view, p p1, boolean flag, boolean flag1)
    {
        if (!f)
        {
            return 0;
        }
        s s1;
        l l1;
        o o1;
        boolean flag2;
        boolean flag3;
        if (flag)
        {
            s1 = p1.b;
        } else
        {
            s1 = p1.a;
        }
        if (flag)
        {
            l1 = b;
        } else
        {
            l1 = c;
        }
        o1 = s1.c;
        if (flag && b(this))
        {
            if (!flag1)
            {
                flag2 = true;
            } else
            {
                flag2 = false;
            }
        } else
        {
            flag2 = flag1;
        }
        if (flag2)
        {
            if (o1.a == 0)
            {
                flag3 = true;
            } else
            {
                flag3 = false;
            }
        } else
        if (o1.b == l1.a())
        {
            flag3 = true;
        } else
        {
            flag3 = false;
        }
        return a(view, flag3, flag, flag1);
    }

    private int a(View view, boolean flag, boolean flag1, boolean flag2)
    {
        if (flag)
        {
            return 0;
        } else
        {
            return b(view, flag1, flag2);
        }
    }

    static int a(int ai[], int i1)
    {
        int j1 = 0;
        for (int k1 = ai.length; j1 < k1; j1++)
        {
            i1 = Math.max(i1, ai[j1]);
        }

        return i1;
    }

    static i a(int i1, boolean flag)
    {
        byte byte0;
        int j1;
        if (flag)
        {
            byte0 = 7;
        } else
        {
            byte0 = 112;
        }
        if (flag)
        {
            j1 = 0;
        } else
        {
            j1 = 4;
        }
        switch ((byte0 & i1) >> j1)
        {
        default:
            return j;

        case 3: // '\003'
            return t;

        case 5: // '\005'
            return u;

        case 7: // '\007'
            return s;

        case 1: // '\001'
            return q;

        case 8388611: 
            return m;

        case 8388613: 
            return n;
        }
    }

    private static i a(i i1, i j1)
    {
        return new d(i1, j1);
    }

    public static s a(int i1)
    {
        return a(i1, 1);
    }

    public static s a(int i1, int j1)
    {
        return a(i1, j1, j);
    }

    public static s a(int i1, int j1, i k1)
    {
        boolean flag;
        if (i1 != 0x80000000)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        return new s(flag, i1, j1, k1, null);
    }

    private void a(int i1, int j1, boolean flag)
    {
        int k1 = getChildCount();
        int l1 = 0;
        while (l1 < k1) 
        {
            View view = getChildAt(l1);
            if (view.getVisibility() != 8)
            {
                p p1 = a(view);
                if (flag)
                {
                    a(view, i1, j1, p1.width, p1.height);
                } else
                {
                    boolean flag1;
                    s s1;
                    if (e == 0)
                    {
                        flag1 = true;
                    } else
                    {
                        flag1 = false;
                    }
                    if (flag1)
                    {
                        s1 = p1.b;
                    } else
                    {
                        s1 = p1.a;
                    }
                    if (s1.d == s)
                    {
                        o o1 = s1.c;
                        l l2;
                        int ai[];
                        int i2;
                        if (flag1)
                        {
                            l2 = b;
                        } else
                        {
                            l2 = c;
                        }
                        ai = l2.f();
                        i2 = ai[o1.b] - ai[o1.a] - b(view, flag1);
                        if (flag1)
                        {
                            a(view, i1, j1, i2, p1.height);
                        } else
                        {
                            a(view, i1, j1, p1.width, i2);
                        }
                    }
                }
            }
            l1++;
        }
    }

    private static void a(p p1, int i1, int j1, int k1, int l1)
    {
        p1.a(new o(i1, i1 + j1));
        p1.b(new o(k1, k1 + l1));
    }

    private void a(View view, int i1, int j1, int k1, int l1)
    {
        view.measure(getChildMeasureSpec(i1, mPaddingLeft + mPaddingRight + b(view, true), k1), getChildMeasureSpec(j1, mPaddingTop + mPaddingBottom + b(view, false), l1));
    }

    private static boolean a(int ai[], int i1, int j1, int k1)
    {
        if (k1 > ai.length)
        {
            return false;
        }
_L3:
        if (j1 < k1)
        {
            if (ai[j1] > i1)
            {
                return false;
            }
        } else
        {
            return true;
        }
        if (true) goto _L2; else goto _L1
_L2:
        j1++;
        if (true) goto _L3; else goto _L1
_L1:
    }

    static Object[] a(Object aobj[], Object aobj1[])
    {
        Object aobj2[] = (Object[])(Object[])Array.newInstance(((Object) (aobj)).getClass().getComponentType(), aobj.length + aobj1.length);
        System.arraycopy(((Object) (aobj)), 0, ((Object) (aobj2)), 0, aobj.length);
        System.arraycopy(((Object) (aobj1)), 0, ((Object) (aobj2)), aobj.length, aobj1.length);
        return aobj2;
    }

    private int b(View view, boolean flag)
    {
        return c(view, flag, true) + c(view, flag, false);
    }

    private int b(View view, boolean flag, boolean flag1)
    {
        if (view.getClass() == android/support/v7/widget/t)
        {
            return 0;
        } else
        {
            return h / 2;
        }
    }

    private void b()
    {
        boolean flag;
        l l1;
        int i1;
        int ai[];
        int j1;
        int k1;
        int i2;
        int j2;
        if (e == 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            l1 = b;
        } else
        {
            l1 = c;
        }
        if (l1.b != 0x80000000)
        {
            i1 = l1.b;
        } else
        {
            i1 = 0;
        }
        ai = new int[i1];
        j1 = getChildCount();
        k1 = 0;
        i2 = 0;
        j2 = 0;
        while (k1 < j1) 
        {
            p p1 = (p)getChildAt(k1).getLayoutParams();
            s s1;
            o o1;
            boolean flag1;
            int k2;
            s s2;
            o o2;
            boolean flag2;
            int l2;
            int i3;
            if (flag)
            {
                s1 = p1.a;
            } else
            {
                s1 = p1.b;
            }
            o1 = s1.c;
            flag1 = s1.b;
            k2 = o1.a();
            if (flag1)
            {
                j2 = o1.a;
            }
            if (flag)
            {
                s2 = p1.b;
            } else
            {
                s2 = p1.a;
            }
            o2 = s2.c;
            flag2 = s2.b;
            l2 = a(o2, flag2, i1);
            if (flag2)
            {
                i3 = o2.a;
            } else
            {
                i3 = i2;
            }
            if (i1 != 0)
            {
                if (!flag1 || !flag2)
                {
                    while (!a(ai, j2, i3, i3 + l2)) 
                    {
                        if (flag2)
                        {
                            j2++;
                        } else
                        if (i3 + l2 <= i1)
                        {
                            i3++;
                        } else
                        {
                            j2++;
                            i3 = 0;
                        }
                    }
                }
                b(ai, i3, i3 + l2, j2 + k2);
            }
            if (flag)
            {
                a(p1, j2, k2, i3, l2);
            } else
            {
                a(p1, i3, l2, j2, k2);
            }
            i2 = i3 + l2;
            k1++;
        }
        i = e();
        c();
    }

    private static void b(int ai[], int i1, int j1, int k1)
    {
        int l1 = ai.length;
        Arrays.fill(ai, Math.min(i1, l1), Math.min(j1, l1), k1);
    }

    static boolean b(int i1)
    {
        return (i1 & 2) != 0;
    }

    private int c(View view, boolean flag)
    {
        if (flag)
        {
            return view.getMeasuredWidth();
        } else
        {
            return view.getMeasuredHeight();
        }
    }

    private int c(View view, boolean flag, boolean flag1)
    {
        if (g == 1)
        {
            return a(view, flag, flag1);
        }
        l l1;
        int ai[];
        p p1;
        s s1;
        int i1;
        if (flag)
        {
            l1 = b;
        } else
        {
            l1 = c;
        }
        if (flag1)
        {
            ai = l1.d();
        } else
        {
            ai = l1.e();
        }
        p1 = a(view);
        if (flag)
        {
            s1 = p1.b;
        } else
        {
            s1 = p1.a;
        }
        if (flag1)
        {
            i1 = s1.c.a;
        } else
        {
            i1 = s1.c.b;
        }
        return ai[i1];
    }

    private void c()
    {
        d = false;
        b.g();
        c.g();
        d();
    }

    private void d()
    {
        if (b != null && c != null)
        {
            b.h();
            c.h();
        }
    }

    private int e()
    {
        int i1 = 1;
        int j1 = getChildCount();
        int k1 = 0;
        while (k1 < j1) 
        {
            View view = getChildAt(k1);
            int l1;
            if (view.getVisibility() == 8)
            {
                l1 = i1;
            } else
            {
                p p1 = (p)view.getLayoutParams();
                l1 = i1 * 31 + p1.hashCode();
            }
            k1++;
            i1 = l1;
        }
        return i1;
    }

    private void f()
    {
        int i1 = e();
        if (i != 0 && i != i1)
        {
            c();
            Log.w(a, "The fields of some layout parameters were modified in between layout operations. Check the javadoc for GridLayout.LayoutParams#rowSpec.");
        }
    }

    final int a(View view, boolean flag)
    {
        if (view.getVisibility() == 8)
        {
            return 0;
        } else
        {
            return c(view, flag) + b(view, flag);
        }
    }

    int a(View view, boolean flag, boolean flag1)
    {
        p p1 = a(view);
        int i1;
        if (flag)
        {
            if (flag1)
            {
                i1 = p1.leftMargin;
            } else
            {
                i1 = p1.rightMargin;
            }
        } else
        if (flag1)
        {
            i1 = p1.topMargin;
        } else
        {
            i1 = p1.bottomMargin;
        }
        if (i1 == 0x80000000)
        {
            i1 = a(view, p1, flag, flag1);
        }
        return i1;
    }

    final i a(i i1, boolean flag)
    {
        if (i1 != j)
        {
            return i1;
        }
        if (flag)
        {
            return m;
        } else
        {
            return r;
        }
    }

    protected p a()
    {
        return new p();
    }

    public p a(AttributeSet attributeset)
    {
        return new p(getContext(), attributeset);
    }

    final p a(View view)
    {
        if (!d)
        {
            b();
            d = true;
        }
        return (p)view.getLayoutParams();
    }

    protected p a(android.view.ViewGroup.LayoutParams layoutparams)
    {
        return new p(layoutparams);
    }

    protected android.view.ViewGroup.LayoutParams generateDefaultLayoutParams()
    {
        return a();
    }

    public android.view.ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeset)
    {
        return a(attributeset);
    }

    protected android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutparams)
    {
        return a(layoutparams);
    }

    public int getAlignmentMode()
    {
        return g;
    }

    public int getColumnCount()
    {
        return b.a();
    }

    public int getOrientation()
    {
        return e;
    }

    public int getRowCount()
    {
        return c.a();
    }

    public boolean getUseDefaultMargins()
    {
        return f;
    }

    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityevent)
    {
        super.onInitializeAccessibilityEvent(accessibilityevent);
        accessibilityevent.setClassName(android/support/v7/widget/GridLayout.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilitynodeinfo)
    {
        super.onInitializeAccessibilityNodeInfo(accessibilitynodeinfo);
        accessibilitynodeinfo.setClassName(android/support/v7/widget/GridLayout.getName());
    }

    protected void onLayout(boolean flag, int i1, int j1, int k1, int l1)
    {
        f();
        int i2 = k1 - i1;
        int j2 = l1 - j1;
        int k2 = getPaddingLeft();
        int l2 = getPaddingTop();
        int i3 = getPaddingRight();
        int j3 = getPaddingBottom();
        b.c(i2 - k2 - i3);
        c.c(j2 - l2 - j3);
        int ai[] = b.f();
        int ai1[] = c.f();
        int k3 = getChildCount();
        int l3 = 0;
        while (l3 < k3) 
        {
            View view = getChildAt(l3);
            if (view.getVisibility() != 8)
            {
                p p1 = a(view);
                s s1 = p1.b;
                s s2 = p1.a;
                o o1 = s1.c;
                o o2 = s2.c;
                int i4 = ai[o1.a];
                int j4 = ai1[o2.a];
                int k4 = ai[o1.b];
                int l4 = ai1[o2.b];
                int i5 = k4 - i4;
                int j5 = l4 - j4;
                int k5 = c(view, true);
                int l5 = c(view, false);
                i i6 = a(s1.d, true);
                i j6 = a(s2.d, false);
                n n1 = (n)b.b().a(l3);
                n n2 = (n)c.b().a(l3);
                int k6 = i6.a(view, i5 - n1.a(true));
                int l6 = j6.a(view, j5 - n2.a(true));
                int i7 = c(view, true, true);
                int j7 = c(view, false, true);
                int k7 = c(view, true, false);
                int l7 = c(view, false, false);
                int i8 = n1.a(view, i6, k7 + (i7 + k5));
                int j8 = n2.a(view, j6, l7 + (j7 + l5));
                int k8 = i6.a(view, k5, i5 - i7 - k7);
                int l8 = j6.a(view, l5, j5 - j7 - l7);
                int i9 = i8 + (i4 + k6);
                int j9;
                int k9;
                if (!b(this))
                {
                    j9 = i9 + (k2 + i7);
                } else
                {
                    j9 = i2 - k8 - i3 - k7 - i9;
                }
                k9 = j7 + (j8 + (l6 + (l2 + j4)));
                if (k8 != view.getMeasuredWidth() || l8 != view.getMeasuredHeight())
                {
                    view.measure(android.view.View.MeasureSpec.makeMeasureSpec(k8, 0x40000000), android.view.View.MeasureSpec.makeMeasureSpec(l8, 0x40000000));
                }
                view.layout(j9, k9, k8 + j9, l8 + k9);
            }
            l3++;
        }
    }

    protected void onMeasure(int i1, int j1)
    {
        f();
        d();
        a(i1, j1, true);
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        if (e == 0)
        {
            l1 = b.b(i1);
            a(i1, j1, false);
            k1 = c.b(j1);
        } else
        {
            k1 = c.b(j1);
            a(i1, j1, false);
            l1 = b.b(i1);
        }
        i2 = getPaddingLeft() + getPaddingRight();
        j2 = getPaddingTop() + getPaddingBottom();
        k2 = Math.max(l1 + i2, getSuggestedMinimumWidth());
        l2 = Math.max(k1 + j2, getSuggestedMinimumHeight());
        setMeasuredDimension(a(k2, i1, 0), a(l2, j1, 0));
    }

    public void requestLayout()
    {
        super.requestLayout();
        d();
    }

    public void setAlignmentMode(int i1)
    {
        g = i1;
        requestLayout();
    }

    public void setColumnCount(int i1)
    {
        b.a(i1);
        c();
        requestLayout();
    }

    public void setColumnOrderPreserved(boolean flag)
    {
        b.a(flag);
        c();
        requestLayout();
    }

    public void setOrientation(int i1)
    {
        if (e != i1)
        {
            e = i1;
            c();
            requestLayout();
        }
    }

    public void setRowCount(int i1)
    {
        c.a(i1);
        c();
        requestLayout();
    }

    public void setRowOrderPreserved(boolean flag)
    {
        c.a(flag);
        c();
        requestLayout();
    }

    public void setUseDefaultMargins(boolean flag)
    {
        f = flag;
        requestLayout();
    }

    static 
    {
        t = new android.support.v7.widget.b();
        u = new android.support.v7.widget.c();
        k = t;
        l = u;
        m = t;
        n = u;
        o = a(m, n);
        p = a(n, m);
    }
}
