// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.util.Pair;
import java.lang.reflect.Array;
import java.util.ArrayList;

// Referenced classes of package android.support.v7.widget:
//            r

final class k extends ArrayList
{

    private final Class a;
    private final Class b;

    private k(Class class1, Class class2)
    {
        a = class1;
        b = class2;
    }

    public static k a(Class class1, Class class2)
    {
        return new k(class1, class2);
    }

    public r a()
    {
        int i = size();
        Object aobj[] = (Object[])(Object[])Array.newInstance(a, i);
        Object aobj1[] = (Object[])(Object[])Array.newInstance(b, i);
        for (int j = 0; j < i; j++)
        {
            aobj[j] = ((Pair)get(j)).first;
            aobj1[j] = ((Pair)get(j)).second;
        }

        return new r(aobj, aobj1, null);
    }

    public void a(Object obj, Object obj1)
    {
        add(Pair.create(obj, obj1));
    }
}
