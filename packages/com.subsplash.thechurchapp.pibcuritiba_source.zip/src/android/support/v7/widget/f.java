// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;

import android.view.View;

// Referenced classes of package android.support.v7.widget:
//            i, g, n

final class f extends i
{

    f()
    {
    }

    int a(View view, int j)
    {
        return 0;
    }

    public n a()
    {
        return new g(this);
    }

    public int b(View view, int j)
    {
        int k = view.getBaseline();
        if (k == -1)
        {
            k = 0x80000000;
        }
        return k;
    }
}
