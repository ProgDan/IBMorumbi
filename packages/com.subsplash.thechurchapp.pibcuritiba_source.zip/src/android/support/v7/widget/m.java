// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.widget;


// Referenced classes of package android.support.v7.widget:
//            GridLayout, j, l, o

class m
{

    static final boolean e;
    j a[];
    int b;
    j c[][];
    int d[];
    final j f[];
    final l g;

    m(l l1, j aj[])
    {
        g = l1;
        f = aj;
        super();
        a = new j[f.length];
        b = -1 + a.length;
        c = g.a(f);
        d = new int[1 + g.a()];
    }

    void a(int i)
    {
        d[i];
        JVM INSTR tableswitch 0 1: default 28
    //                   0 29
    //                   1 114;
           goto _L1 _L2 _L3
_L1:
        return;
_L2:
        d[i] = 1;
        j aj[] = c[i];
        int k = aj.length;
        for (int i1 = 0; i1 < k; i1++)
        {
            j j1 = aj[i1];
            a(j1.a.b);
            j aj1[] = a;
            int k1 = b;
            b = k1 - 1;
            aj1[k1] = j1;
        }

        d[i] = 2;
        return;
_L3:
        if (!e)
        {
            throw new AssertionError();
        }
        if (true) goto _L1; else goto _L4
_L4:
    }

    j[] a()
    {
        int i = 0;
        for (int k = c.length; i < k; i++)
        {
            a(i);
        }

        if (!e && b != -1)
        {
            throw new AssertionError();
        } else
        {
            return a;
        }
    }

    static 
    {
        boolean flag;
        if (!android/support/v7/widget/GridLayout.desiredAssertionStatus())
        {
            flag = true;
        } else
        {
            flag = false;
        }
        e = flag;
    }
}
