// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v7.a;


public final class c
{

    public static final int GridLayout[] = {
        0x7f010000, 0x7f010001, 0x7f010002, 0x7f010003, 0x7f010004, 0x7f010005, 0x7f010006
    };
    public static final int GridLayout_Layout[] = {
        0x10100f4, 0x10100f5, 0x10100f6, 0x10100f7, 0x10100f8, 0x10100f9, 0x10100fa, 0x7f010007, 0x7f010008, 0x7f010009, 
        0x7f01000a, 0x7f01000b
    };
    public static final int GridLayout_Layout_android_layout_height = 1;
    public static final int GridLayout_Layout_android_layout_margin = 2;
    public static final int GridLayout_Layout_android_layout_marginBottom = 6;
    public static final int GridLayout_Layout_android_layout_marginLeft = 3;
    public static final int GridLayout_Layout_android_layout_marginRight = 5;
    public static final int GridLayout_Layout_android_layout_marginTop = 4;
    public static final int GridLayout_Layout_android_layout_width = 0;
    public static final int GridLayout_Layout_layout_column = 9;
    public static final int GridLayout_Layout_layout_columnSpan = 10;
    public static final int GridLayout_Layout_layout_gravity = 11;
    public static final int GridLayout_Layout_layout_row = 7;
    public static final int GridLayout_Layout_layout_rowSpan = 8;
    public static final int GridLayout_alignmentMode = 4;
    public static final int GridLayout_columnCount = 2;
    public static final int GridLayout_columnOrderPreserved = 6;
    public static final int GridLayout_orientation = 0;
    public static final int GridLayout_rowCount = 1;
    public static final int GridLayout_rowOrderPreserved = 5;
    public static final int GridLayout_useDefaultMargins = 3;

}
