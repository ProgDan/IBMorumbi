// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import android.app.Activity;
import android.graphics.drawable.Drawable;

class <init>
    implements <init>
{

    public Drawable getThemeUpIndicator(Activity activity)
    {
        return null;
    }

    public Object setActionBarDescription(Object obj, Activity activity, int i)
    {
        return obj;
    }

    public Object setActionBarUpIndicator(Object obj, Activity activity, Drawable drawable, int i)
    {
        return obj;
    }

    private ()
    {
    }

    ( )
    {
        this();
    }
}
