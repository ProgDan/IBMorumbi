// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.app;

import java.util.ArrayList;
import java.util.HashMap;

final class 
{

    Object activity;
    HashMap children;
    Object custom;
    ArrayList fragments;
    HashMap loaders;

    ()
    {
    }
}
