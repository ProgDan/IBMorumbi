// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;

import android.view.accessibility.AccessibilityEvent;

class pl
    implements pl
{

    public void appendRecord(AccessibilityEvent accessibilityevent, Object obj)
    {
    }

    public Object getRecord(AccessibilityEvent accessibilityevent, int i)
    {
        return null;
    }

    public int getRecordCount(AccessibilityEvent accessibilityevent)
    {
        return 0;
    }

    pl()
    {
    }
}
