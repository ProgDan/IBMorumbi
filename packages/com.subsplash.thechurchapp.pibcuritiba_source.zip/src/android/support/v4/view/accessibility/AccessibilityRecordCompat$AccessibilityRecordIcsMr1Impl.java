// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;


// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityRecordCompatIcsMr1

class  extends 
{

    public int getMaxScrollX(Object obj)
    {
        return AccessibilityRecordCompatIcsMr1.getMaxScrollX(obj);
    }

    public int getMaxScrollY(Object obj)
    {
        return AccessibilityRecordCompatIcsMr1.getMaxScrollY(obj);
    }

    public void setMaxScrollX(Object obj, int i)
    {
        AccessibilityRecordCompatIcsMr1.setMaxScrollX(obj, i);
    }

    public void setMaxScrollY(Object obj, int i)
    {
        AccessibilityRecordCompatIcsMr1.setMaxScrollY(obj, i);
    }

    ()
    {
    }
}
