// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import android.os.Bundle;
import android.util.Log;
import android.webkit.CookieSyncManager;

// Referenced classes of package com.a.a:
//            h, f, i, e

class g
    implements h
{

    final f a;

    g(f f1)
    {
        a = f1;
        super();
    }

    public void a()
    {
        Log.d("Facebook-authorize", "Login canceled");
        f.a(a).a();
    }

    public void a(Bundle bundle)
    {
        CookieSyncManager.getInstance().sync();
        a.a(bundle.getString("access_token"));
        a.b(bundle.getString("expires_in"));
        if (a.a())
        {
            Log.d("Facebook-authorize", (new StringBuilder()).append("Login Success! access_token=").append(a.b()).append(" expires=").append(a.c()).toString());
            f.a(a).a(bundle);
            return;
        } else
        {
            f.a(a).a(new i("Failed to receive access token."));
            return;
        }
    }

    public void a(e e)
    {
        Log.d("Facebook-authorize", (new StringBuilder()).append("Login failed: ").append(e).toString());
        f.a(a).a(e);
    }

    public void a(i j)
    {
        Log.d("Facebook-authorize", (new StringBuilder()).append("Login failed: ").append(j).toString());
        f.a(a).a(j);
    }
}
