// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import android.os.Bundle;

// Referenced classes of package com.a.a:
//            e, i

public interface h
{

    public abstract void a();

    public abstract void a(Bundle bundle);

    public abstract void a(e e);

    public abstract void a(i i);
}
