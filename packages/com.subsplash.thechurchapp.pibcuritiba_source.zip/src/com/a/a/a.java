// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import android.content.Context;
import android.os.Bundle;

// Referenced classes of package com.a.a:
//            b, c, f, d

public class a
{

    f a;

    public a(f f)
    {
        a = f;
    }

    public void a(Context context, d d)
    {
        a(context, d, null);
    }

    public void a(Context context, d d, Object obj)
    {
        (new b(this, context, d, obj)).start();
    }

    public void a(String s, Bundle bundle, String s1, d d, Object obj)
    {
        (new c(this, s, bundle, s1, d, obj)).start();
    }
}
