// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

// Referenced classes of package com.a.a:
//            j, e, h, m, 
//            i, k

class l extends WebViewClient
{

    final j a;

    private l(j j1)
    {
        a = j1;
        super();
    }

    l(j j1, k k)
    {
        this(j1);
    }

    public void onPageFinished(WebView webview, String s)
    {
        super.onPageFinished(webview, s);
        String s1 = j.c(a).getTitle();
        if (s1 != null && s1.length() > 0)
        {
            j.d(a).setText(s1);
        }
        j.b(a).dismiss();
    }

    public void onPageStarted(WebView webview, String s, Bitmap bitmap)
    {
        Log.d("Facebook-WebView", (new StringBuilder()).append("Webview loading URL: ").append(s).toString());
        super.onPageStarted(webview, s, bitmap);
        j.b(a).show();
    }

    public void onReceivedError(WebView webview, int k, String s, String s1)
    {
        super.onReceivedError(webview, k, s, s1);
        j.a(a).a(new e(s, k, s1));
        a.dismiss();
    }

    public boolean shouldOverrideUrlLoading(WebView webview, String s)
    {
        Log.d("Facebook-WebView", (new StringBuilder()).append("Redirect URL: ").append(s).toString());
        if (s.startsWith("fbconnect://success"))
        {
            Bundle bundle = m.b(s);
            String s1 = bundle.getString("error");
            if (s1 == null)
            {
                s1 = bundle.getString("error_type");
            }
            if (s1 == null)
            {
                j.a(a).a(bundle);
            } else
            if (s1.equals("access_denied") || s1.equals("OAuthAccessDeniedException"))
            {
                j.a(a).a();
            } else
            {
                j.a(a).a(new i(s1));
            }
            a.dismiss();
            return true;
        }
        if (s.startsWith("fbconnect://cancel"))
        {
            j.a(a).a();
            a.dismiss();
            return true;
        }
        if (s.contains("touch"))
        {
            return false;
        } else
        {
            a.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(s)));
            return true;
        }
    }
}
