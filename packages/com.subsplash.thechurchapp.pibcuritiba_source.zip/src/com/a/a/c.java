// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import android.os.Bundle;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;

// Referenced classes of package com.a.a:
//            a, f, d

class c extends Thread
{

    final String a;
    final Bundle b;
    final String c;
    final d d;
    final Object e;
    final a f;

    c(a a1, String s, Bundle bundle, String s1, d d1, Object obj)
    {
        f = a1;
        a = s;
        b = bundle;
        c = s1;
        d = d1;
        e = obj;
        super();
    }

    public void run()
    {
        try
        {
            String s = f.a.a(a, b, c);
            d.a(s, e);
            return;
        }
        catch (FileNotFoundException filenotfoundexception)
        {
            d.a(filenotfoundexception, e);
            return;
        }
        catch (MalformedURLException malformedurlexception)
        {
            d.a(malformedurlexception, e);
            return;
        }
        catch (IOException ioexception)
        {
            d.a(ioexception, e);
        }
    }
}
