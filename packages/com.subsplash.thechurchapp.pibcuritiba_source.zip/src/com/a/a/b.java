// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import android.content.Context;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;

// Referenced classes of package com.a.a:
//            a, f, i, d

class b extends Thread
{

    final Context a;
    final d b;
    final Object c;
    final a d;

    b(a a1, Context context, d d1, Object obj)
    {
        d = a1;
        a = context;
        b = d1;
        c = obj;
        super();
    }

    public void run()
    {
        String s;
        s = d.a.a(a);
        if (s.length() == 0 || s.equals("false"))
        {
            b.a(new i("auth.expireSession failed"), c);
            return;
        }
        try
        {
            b.a(s, c);
            return;
        }
        catch (FileNotFoundException filenotfoundexception)
        {
            b.a(filenotfoundexception, c);
            return;
        }
        catch (MalformedURLException malformedurlexception)
        {
            b.a(malformedurlexception, c);
            return;
        }
        catch (IOException ioexception)
        {
            b.a(ioexception, c);
        }
        return;
    }
}
