// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;


public class e extends Throwable
{

    private int a;
    private String b;

    public e(String s, int i, String s1)
    {
        super(s);
        a = i;
        b = s1;
    }
}
