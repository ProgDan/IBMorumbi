// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

// Referenced classes of package com.a.a:
//            l, h

public class j extends Dialog
{

    static final float a[] = {
        20F, 60F
    };
    static final float b[] = {
        40F, 60F
    };
    static final android.widget.FrameLayout.LayoutParams c = new android.widget.FrameLayout.LayoutParams(-1, -1);
    private String d;
    private h e;
    private ProgressDialog f;
    private WebView g;
    private LinearLayout h;
    private TextView i;

    public j(Context context, String s, h h1)
    {
        super(context);
        d = s;
        e = h1;
    }

    static h a(j j1)
    {
        return j1.e;
    }

    private void a()
    {
        requestWindowFeature(1);
        android.graphics.drawable.Drawable drawable = getContext().getResources().getDrawable(0x7f020000);
        i = new TextView(getContext());
        i.setText("Facebook");
        i.setTextColor(-1);
        i.setTypeface(Typeface.DEFAULT_BOLD);
        i.setBackgroundColor(0xff6d84b4);
        i.setPadding(6, 4, 4, 4);
        i.setCompoundDrawablePadding(6);
        i.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null);
        h.addView(i);
    }

    static ProgressDialog b(j j1)
    {
        return j1.f;
    }

    private void b()
    {
        g = new WebView(getContext());
        g.setVerticalScrollBarEnabled(false);
        g.setHorizontalScrollBarEnabled(false);
        g.setWebViewClient(new l(this, null));
        g.getSettings().setJavaScriptEnabled(true);
        g.loadUrl(d);
        g.setLayoutParams(c);
        h.addView(g);
    }

    static WebView c(j j1)
    {
        return j1.g;
    }

    static TextView d(j j1)
    {
        return j1.i;
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        f = new ProgressDialog(getContext());
        f.requestWindowFeature(1);
        f.setMessage("Loading...");
        h = new LinearLayout(getContext());
        h.setOrientation(1);
        a();
        b();
        Display display = getWindow().getWindowManager().getDefaultDisplay();
        float f1 = getContext().getResources().getDisplayMetrics().density;
        float af[];
        if (getContext().getResources().getConfiguration().orientation == 2)
        {
            af = a;
        } else
        {
            af = b;
        }
        addContentView(h, new android.widget.LinearLayout.LayoutParams(display.getWidth() - (int)(0.5F + f1 * af[0]), display.getHeight() - (int)(0.5F + f1 * af[1])));
    }

}
