// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.a.a;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;

// Referenced classes of package com.a.a:
//            i

public interface d
{

    public abstract void a(i i, Object obj);

    public abstract void a(FileNotFoundException filenotfoundexception, Object obj);

    public abstract void a(IOException ioexception, Object obj);

    public abstract void a(String s, Object obj);

    public abstract void a(MalformedURLException malformedurlexception, Object obj);
}
