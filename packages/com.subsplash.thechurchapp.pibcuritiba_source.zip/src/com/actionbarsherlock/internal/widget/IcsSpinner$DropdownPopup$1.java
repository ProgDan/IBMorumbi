// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.actionbarsherlock.internal.widget;

import android.view.View;
import android.widget.AdapterView;

// Referenced classes of package com.actionbarsherlock.internal.widget:
//            IcsSpinner

class val.this._cls0
    implements android.widget.ener
{

    final smiss this$1;
    final IcsSpinner val$this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        setSelection(i);
        smiss();
    }

    ()
    {
        this$1 = final_;
        val$this$0 = IcsSpinner.this;
        super();
    }
}
